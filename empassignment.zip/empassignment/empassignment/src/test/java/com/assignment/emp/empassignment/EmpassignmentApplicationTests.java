package com.assignment.emp.empassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpassignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
