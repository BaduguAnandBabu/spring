insert into employee(id, name, last_name) 
values(100,'Anand','badugu');
insert into employee (id, name, last_name) 
values(101,'sanjay' ,'badugu' );
insert into employee(id, name, last_name ) 
values(102,'surya', 'chandhra');



















